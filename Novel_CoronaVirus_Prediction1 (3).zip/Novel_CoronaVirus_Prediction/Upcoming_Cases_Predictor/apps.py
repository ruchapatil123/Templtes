from django.apps import AppConfig


class UpcomingCasesPredictorConfig(AppConfig):
    name = 'Upcoming_Cases_Predictor'
